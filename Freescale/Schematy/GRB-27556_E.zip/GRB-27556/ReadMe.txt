README for GRB-27556_E.zip

Company Part Number: 170-27556 REV E

Date : Fri, 01 Feb 2013 15:08:26 GMT

Freescale 
Periferico Sur 8110
45609
Tlaquepaque Jalisco, Mexico

Company Contact: Mario velasco
	Work Phone: (52)3332832208
		 Email:	 mario.velascogonzalez@freescale.com